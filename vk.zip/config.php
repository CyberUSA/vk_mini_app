<?php
require 'func.php';
//Разработчик: Telegram - @S1m3ntr1ya
//Если нужен кодер пиши
//PHP
//Python
//JavaScript
//NodeJS
//ReactJS
//C#



//Файл создан с целью того что функционал будет обновлен мною или другим пользователем!

?>